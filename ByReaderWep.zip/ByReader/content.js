if (document.getElementById('my-super-reader')) {
  document.getElementById('my-super-reader').remove();
  document.body.style.overflow = ''; 
} else {
  // 본문 가져오기
  let contentNode = document.querySelector('article') || document.querySelector('main') || document.body;
  let originalHTML = contentNode.innerHTML;

  // 전체 화면 리더기 생성
  const readerDiv = document.createElement('div');
  readerDiv.id = 'my-super-reader';
  readerDiv.className = 'theme-ivory';

  // 툴바에 모든 메뉴 부활
  readerDiv.innerHTML = `
    <div id="sr-toolbar">
      <div class="sr-group">
        <span class="sr-label">크기</span>
        <input type="range" id="sr-size" min="14" max="36" value="18">
      </div>
      <div class="sr-divider"></div>
      <div class="sr-group">
        <span class="sr-label">행간</span>
        <input type="range" id="sr-line" min="140" max="260" value="180">
      </div>
      <div class="sr-divider"></div>
      <div class="sr-group">
        <span class="sr-label">너비</span>
        <input type="range" id="sr-width" min="500" max="1200" value="800">
      </div>
      <div class="sr-divider"></div>
      <div class="sr-group">
        <button id="sr-focus" class="sr-btn" title="방향키(↓,↑)로 문단 이동">포커스</button>
        <button id="sr-bionic" class="sr-btn">바이오닉</button>
      </div>
      <div class="sr-divider"></div>
      <div class="sr-group">
        <select id="sr-font" class="sr-btn">
          <option value="'Pretendard', sans-serif">프리텐다드</option>
          <option value="'Noto Serif KR', serif">본명조</option>
          <option value="'Gowun Dodum', sans-serif">고운 돋움</option>
        </select>
        <select id="sr-theme" class="sr-btn">
          <option value="theme-ivory">미색 노트</option>
          <option value="theme-dark">다크 모드</option>
        </select>
        <button id="sr-close" class="sr-btn" style="color:red; font-weight:bold;">끄기 ✖</button>
      </div>
    </div>
    <div id="sr-content-area">${originalHTML}</div>
  `;

  document.body.appendChild(readerDiv);
  document.body.style.overflow = 'hidden';

  const contentArea = document.getElementById('sr-content-area');

  // --- 1. 기본 슬라이더 & 선택 기능 ---
  document.getElementById('sr-size').addEventListener('input', (e) => readerDiv.style.setProperty('--font-size', e.target.value + 'px'));
  document.getElementById('sr-line').addEventListener('input', (e) => readerDiv.style.setProperty('--line-height', (e.target.value / 100).toFixed(2)));
  document.getElementById('sr-width').addEventListener('input', (e) => readerDiv.style.setProperty('--col-width', e.target.value + 'px'));
  document.getElementById('sr-font').addEventListener('change', (e) => readerDiv.style.setProperty('--font-family', e.target.value));
  document.getElementById('sr-theme').addEventListener('change', (e) => {
    readerDiv.className = document.getElementById('sr-focus').classList.contains('active') ? `focus-mode ${e.target.value}` : e.target.value;
  });

  // --- 2. 바이오닉 리딩 (DOM 안전 변환) ---
  let isBionic = false;
  document.getElementById('sr-bionic').addEventListener('click', (e) => {
    isBionic = !isBionic;
    e.target.classList.toggle('active', isBionic);
    
    if (!isBionic) {
      contentArea.innerHTML = originalHTML; // 원상 복구
    } else {
      // 텍스트만 찾아서 바이오닉 적용 (이미지 깨짐 방지)
      const walker = document.createTreeWalker(contentArea, NodeFilter.SHOW_TEXT, null, false);
      const nodes = [];
      let node;
      while (node = walker.nextNode()) {
        if (node.parentElement.tagName !== 'SCRIPT' && node.parentElement.tagName !== 'STYLE' && node.nodeValue.trim() !== '') {
          nodes.push(node);
        }
      }
      nodes.forEach(textNode => {
        const span = document.createElement('span');
        span.innerHTML = textNode.nodeValue.replace(/[a-zA-Z가-힣0-9]+/g, match => {
          let len = match.length;
          if (len === 1) return `<b class="bio">${match}</b>`;
          let boldLen = Math.ceil(len * 0.4);
          if (match.match(/[가-힣]/)) boldLen = len <= 3 ? 1 : Math.ceil(len * 0.5);
          return `<b class="bio">${match.slice(0, boldLen)}</b>${match.slice(boldLen)}`;
        });
        textNode.replaceWith(...span.childNodes);
      });
    }
    updateFocusElements(); // DOM이 바뀌었으니 포커스 요소 재검색
  });

  // --- 3. 포커스 모드 (로직 수정됨!) ---
  let isFocus = false;
  let focusElements = [];
  let currentFocusIndex = -1;

  function updateFocusElements() {
    focusElements = Array.from(contentArea.querySelectorAll('p, h1, h2, h3, h4, li, div')).filter(el => {
      // 내부에 다른 블록 요소(p, div 등)를 품고 있는 껍데기 태그는 제외하고, 글씨가 있는 태그만 추출
      const hasBlockChildren = Array.from(el.children).some(child => 
        ['P', 'DIV', 'UL', 'OL', 'LI', 'H1', 'H2', 'H3', 'H4', 'BLOCKQUOTE'].includes(child.tagName)
      );
      return el.innerText.trim().length > 15 && !hasBlockChildren;
    });
  }
  updateFocusElements();

  document.getElementById('sr-focus').addEventListener('click', (e) => {
    isFocus = !isFocus;
    e.target.classList.toggle('active', isFocus);
    if (isFocus) {
      readerDiv.classList.add('focus-mode');
      if(currentFocusIndex === -1 && focusElements.length > 0) applyFocus(0);
    } else {
      readerDiv.classList.remove('focus-mode');
      if (focusElements[currentFocusIndex]) focusElements[currentFocusIndex].classList.remove('focused');
    }
  });

  function applyFocus(index) {
    if (focusElements.length === 0) return;
    if (focusElements[currentFocusIndex]) focusElements[currentFocusIndex].classList.remove('focused');
    currentFocusIndex = Math.max(0, Math.min(index, focusElements.length - 1));
    const target = focusElements[currentFocusIndex];
    target.classList.add('focused');
    target.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  // 방향키 컨트롤
  document.addEventListener('keydown', (e) => {
    if (isFocus && document.getElementById('my-super-reader')) {
      if (e.key === 'ArrowDown') { e.preventDefault(); applyFocus(currentFocusIndex + 1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); applyFocus(currentFocusIndex - 1); }
    }
  });

  // --- 4. 끄기 ---
  document.getElementById('sr-close').addEventListener('click', () => {
    readerDiv.remove();
    document.body.style.overflow = '';
  });
}