chrome.action.onClicked.addListener((tab) => {
  // 아이콘을 클릭하면 현재 보고 있는 페이지에 CSS와 JS를 주입합니다.
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['content.js']
  });
  chrome.scripting.insertCSS({
    target: { tabId: tab.id },
    files: ['style.css']
  });
});